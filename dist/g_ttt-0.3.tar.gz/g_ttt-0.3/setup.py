from setuptools import setup

setup(name='g_ttt',
      version='0.3',
      author='Gustavo Oliveira',
      description='A cool tic tac toe game',
      author_email='gugmt15@gmail.com',
      packages=['g_ttt'],
      zip_safe=False)
