from setuptools import setup

setup(name='g_ttt',
      version='0.1',
      author='Gustavo Oliveira',
      author_email='gugmt15@gmail.com',
      description='Tic Tac Toe game',
      packages=['g_ttt'],
      zip_safe=False)
