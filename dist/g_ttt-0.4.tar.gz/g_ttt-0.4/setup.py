from setuptools import setup

setup(name='g_ttt',
      version='0.4',
      author='Gustavo Oliveira',
      description='Tic tac toe game',
      long_description='A 2-player tic tac toe game to play with a friend',
      author_email='gugmt15@gmail.com',
      packages=['g_ttt'],
      zip_safe=False)
